const supported = ["en", "zh-Hans", "zh-Hant", "ja", "ko", "fr", "es", "de"];
let language = "en";
for (const preference of navigator.languages ?? [navigator.language]) {
  if (typeof preference !== "string") continue;
  const normalized = preference.toLowerCase();
  const primary = normalized.split("-")[0];
  const subtags = normalized.split("-");
  const match = primary === "zh"
    ? subtags.includes("hant") ? "zh-Hant" : subtags.includes("hans") ? "zh-Hans" : subtags.some((tag) => ["tw", "hk", "mo"].includes(tag)) ? "zh-Hant" : "zh-Hans"
    : supported.find((candidate) => candidate === primary);
  if (match) {
    language = match;
    break;
  }
}
const destination = document.querySelector(`link[rel="alternate"][hreflang="${language}"]`);
if (destination) {
  const target = new URL(destination.href);
  if (target.origin === location.origin && location.pathname !== target.pathname) location.replace(`${target.pathname}${location.hash}`);
}
