const languages = new Set(["en", "zh-Hans", "zh-Hant", "ja", "ko", "fr", "es", "de"]);
const guides = ["journal/choosing-teaware/", "journal/looking-at-objects/", "journal/choosing-teaware/"];
const validChannel = (channel) => typeof channel === "string" && /^[a-f0-9]{32}$/.test(channel);

export function heroDestination(slide, basePath) {
  if (!Number.isInteger(slide) || slide < 0 || slide >= guides.length
    || typeof basePath !== "string" || !/^\/(?:[a-zA-Z0-9_-]+\/)+$/.test(basePath)
    || !languages.has(basePath.split("/").at(-2))) return null;
  return `${basePath}${guides[slide]}`;
}

export function decodeHeroMessage(event, { source, origin, channel, basePath }) {
  if (!source || event?.source !== source || typeof origin !== "string" || !/^https?:\/\//.test(origin)
    || event.origin !== origin || !validChannel(channel)) return null;
  const data = event.data;
  if (!data || typeof data !== "object" || Array.isArray(data) || data.channel !== channel) return null;
  const keys = Object.keys(data).sort().join(",");
  if (data.type === "atraro-hero:ready" && keys === "channel,height,type") {
    if (!Number.isFinite(data.height) || data.height <= 0) return null;
    return { type: "ready", height: Math.min(1200, Math.max(150, Math.ceil(data.height))) };
  }
  if (data.type === "atraro-hero:open" && keys === "channel,slide,type") {
    const href = heroDestination(data.slide, basePath);
    return href ? { type: "open", href } : null;
  }
  return null;
}

export function createHeroFrameUrl(entry, origin, language, channel) {
  if (typeof entry !== "string" || !/^\/(?:[a-zA-Z0-9_-]+\/)+index\.html$/.test(entry)
    || !languages.has(language) || !validChannel(channel)) return null;
  try {
    const parent = new URL(origin);
    if (!["http:", "https:"].includes(parent.protocol) || parent.origin !== origin) return null;
    const target = new URL(entry, parent);
    target.searchParams.set("lang", language);
    target.searchParams.set("parentOrigin", origin);
    target.hash = new URLSearchParams({ channel }).toString();
    return target.href;
  } catch {
    return null;
  }
}
