import { createHeroFrameUrl, decodeHeroMessage } from "./hero-protocol.mjs?v=4149c61a43f6";

for (const frame of document.querySelectorAll("iframe[data-hero-entry]")) {
  const section = frame.closest(".campaign-section");
  const stage = section?.querySelector(".campaign-stage");
  const fallback = section?.querySelector(".campaign-fallback");
  if (!stage || !fallback || !globalThis.crypto?.getRandomValues) continue;
  const channel = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, "0")).join("");
  const language = document.documentElement.lang;
  const target = createHeroFrameUrl(frame.dataset.heroEntry, location.origin, language, channel);
  if (!target) continue;
  frame.dataset.language = language;
  window.addEventListener("message", (event) => {
    const message = decodeHeroMessage(event, { source: frame.contentWindow, origin: location.origin, channel, basePath: frame.dataset.basePath });
    if (!message) return;
    if (message.type === "ready") {
      stage.style.height = `${message.height}px`;
      fallback.hidden = true;
      stage.classList.add("campaign-ready");
      frame.removeAttribute("aria-hidden");
      frame.removeAttribute("tabindex");
    } else if (stage.classList.contains("campaign-ready")) {
      location.assign(message.href);
    }
  });
  frame.src = target;
}
