(() => {
  const alternates = new Map([...document.querySelectorAll('link[rel="alternate"][hreflang]')]
    .map((link) => [link.getAttribute("hreflang"), link.href])
    .filter(([code]) => code !== "x-default"));
  // The application reads this SharedPreferences key as a JSON string.
  const preferenceKey = "flutter.qhj.language";
  const preference = (value) => {
    const code = value === "zh" ? "zh-Hans" : value === "zhHant" ? "zh-Hant" : value;
    return alternates.has(code) ? code : null;
  };
  const matchLocale = (value) => {
    if (typeof value !== "string") return null;
    try {
      const locale = new Intl.Locale(value.trim());
      if (locale.language === "zh") {
        if (locale.script === "Hans") return preference("zh-Hans");
        if (locale.script === "Hant") return preference("zh-Hant");
        return preference(["TW", "HK", "MO"].includes(locale.region) ? "zh-Hant" : "zh-Hans");
      }
      return preference(locale.language);
    } catch {
      return null;
    }
  };

  const rememberSelection = (event) => {
    const anchor = event.target?.closest?.("a[hreflang]");
    const code = preference(anchor?.getAttribute("hreflang"));
    if (!code) return;
    const target = new URL(anchor.href);
    if (target.origin !== location.origin) return;
    target.search = location.search;
    if (target.searchParams.has("lang")) target.searchParams.set("lang", code);
    target.hash = location.hash;
    anchor.href = target.href;
    try {
      localStorage.setItem(preferenceKey, JSON.stringify(code));
    } catch {
      // Private browsing or blocked storage must not prevent a language switch.
    }
  };
  for (const navigation of document.querySelectorAll(".language-nav, .language-popup")) {
    navigation.addEventListener("click", rememberSelection);
    navigation.addEventListener("auxclick", (event) => {
      if (event.button === 1) rememberSelection(event);
    });
  }

  // Explicit language pages retain their URL, even when preferences disagree.
  if (document.querySelector("script[data-language-entry]")?.dataset.languageEntry !== "true") return;
  const values = new URL(location.href).searchParams.getAll("lang");
  let language = values.length === 1 ? preference(values[0]) : null;
  if (!language) {
    try {
      language = preference(JSON.parse(localStorage.getItem(preferenceKey)));
    } catch {
      // Ignore unavailable storage or an invalid saved value.
    }
  }
  if (!language) {
    const candidates = [...(navigator.languages ?? []), navigator.language];
    language = candidates.map(matchLocale).find(Boolean);
  }
  if (!language) {
    try {
      language = matchLocale(new Intl.DateTimeFormat().resolvedOptions().locale);
    } catch {
      // The runtime default is optional; English remains the final fallback.
    }
  }
  const href = alternates.get(language ?? "en");
  if (!href) return;
  const target = new URL(href);
  if (target.origin === location.origin && location.pathname !== target.pathname) {
    target.search = location.search;
    target.hash = location.hash;
    location.replace(`${target.pathname}${target.search}${target.hash}`);
  }
})();
