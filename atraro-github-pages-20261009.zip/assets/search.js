const searchForm = document.querySelector("#preview-search");
const searchInput = document.querySelector("#site-search");
const searchStatus = document.querySelector("#search-status");
const searchEntries = [...document.querySelectorAll("#search-results li")];

function filterPages() {
  const normalize = (value) => value.toLocaleLowerCase(document.documentElement.lang).normalize("NFKD").replace(/\p{M}/gu, "");
  const words = normalize(searchInput.value.trim()).split(/\s+/).filter(Boolean);
  let matches = 0;
  for (const entry of searchEntries) {
    const searchable = normalize(entry.dataset.search);
    entry.hidden = !words.every((word) => searchable.includes(word));
    if (!entry.hidden) matches += 1;
  }
  searchStatus.textContent = words.length === 0
    ? searchStatus.dataset.empty
    : matches === 0
      ? searchStatus.dataset.none
      : (matches === 1 ? searchStatus.dataset.one : searchStatus.dataset.many).replace("{count}", String(matches));
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  filterPages();
});
searchInput.addEventListener("input", filterPages);
window.addEventListener("pageshow", () => {
  searchInput.value = "";
  filterPages();
});
